
async function viewEvents() {
  const state = { search: "", city: "", sort: "asc", page: 1 };

  render(`
    <h1>Browse events</h1>
    <div class="toolbar">
      <input id="q" type="search" placeholder="Search title or description…">
      <select id="city"><option value="">All cities</option></select>
      <select id="sort">
        <option value="asc">Soonest first</option>
        <option value="desc">Latest first</option>
      </select>
    </div>
    <div id="list" class="grid">Loading…</div>
    <div id="pager" class="pager"></div>`);

  api("GET", "/venues").then(r => {
    const cities = [...new Set(r.data.map(v => v.city))].sort();
    $("#city").insertAdjacentHTML("beforeend", cities.map(c => `<option>${esc(c)}</option>`).join(""));
  }).catch(() => { /* filter just stays empty */ });

  async function load() {
    const qs = new URLSearchParams({ sort: state.sort, page: state.page, limit: 6 });
    if (state.search) qs.set("search", state.search);
    if (state.city) qs.set("city", state.city);
    try {
      const res = await api("GET", "/events?" + qs);
      const { events, pagination } = res.data;

      $("#list").innerHTML = events.length
        ? events.map(eventCard).join("")
        : `<div class="empty">No events match your search.</div>`;

      $("#pager").innerHTML = pagination.total_pages > 1 ? `
        <button class="btn ghost" id="prev" ${state.page <= 1 ? "disabled" : ""}>&larr; Prev</button>
        <span>Page ${pagination.current_page} of ${pagination.total_pages} · ${pagination.total_records} events</span>
        <button class="btn ghost" id="next" ${state.page >= pagination.total_pages ? "disabled" : ""}>Next &rarr;</button>` : "";
      if ($("#prev")) $("#prev").onclick = () => { state.page--; load(); };
      if ($("#next")) $("#next").onclick = () => { state.page++; load(); };
    } catch (err) {
      $("#list").innerHTML = errorPanel(err);
      $("#pager").innerHTML = "";
    }
  }

  let timer;
  $("#q").oninput = e => { clearTimeout(timer); timer = setTimeout(() => { state.search = e.target.value.trim(); state.page = 1; load(); }, 300); };
  $("#city").onchange = e => { state.city = e.target.value; state.page = 1; load(); };
  $("#sort").onchange = e => { state.sort = e.target.value; state.page = 1; load(); };
  load();
}

function eventState(e) {
  if (isPast(e.event_date)) return { cls: "ended", label: "Ended" };
  if (Number(e.available_tickets) <= 0) return { cls: "soldout", label: "Sold out" };
  if (Number(e.available_tickets) <= Number(e.total_tickets) * 0.1) return { cls: "few", label: "Few left" };
  return { cls: "open", label: "Available" };
}

function eventCard(e) {
  const s = eventState(e);
  return `
    <a class="card event-card" href="#/events/${e.event_id}">
      <div class="card-top"><span class="badge ${s.cls}">${s.label}</span><span class="price">${rm(e.ticket_price)}</span></div>
      <h3>${esc(e.title)}</h3>
      <p class="muted">${esc(fmtDate(e.event_date))}</p>
      <p class="muted">${esc(e.venue_name || "Venue TBA")}${e.city ? ", " + esc(e.city) : ""}</p>
      ${availBar(e.available_tickets, e.total_tickets)}
      <p class="small">${e.available_tickets} of ${e.total_tickets} tickets left</p>
    </a>`;
}

async function viewEventDetail(id) {
  render(`<p><a href="#/events">&larr; Back to events</a></p><div id="box" class="panel">Loading…</div>`);
  try {
    const e = (await api("GET", "/events/" + id)).data;
    drawEventDetail(e);
  } catch (err) { $("#box").outerHTML = errorPanel(err); }
}

function drawEventDetail(e) {
  const s = eventState(e);
  const role = Session.user.role;
  const available = Number(e.available_tickets);
  const canBook = role === "customer" && s.cls !== "ended" && available > 0;

  let bookingPart;
  if (role !== "customer") {
    bookingPart = `<div class="notice">You are logged in as <b>${esc(role)}</b>. Only customers can book tickets.</div>`;
  } else if (s.cls === "ended") {
    bookingPart = `<div class="notice">This event has already taken place.</div>`;
  } else if (available <= 0) {
    bookingPart = `<div class="notice">Sorry, this event is sold out.</div>`;
  } else {
    bookingPart = `
      <form id="bookForm" novalidate>
        <label>Number of tickets
          <input name="quantity" type="number" min="1" max="${available}" value="1">
        </label>
        <p class="total">Total: <b id="total">${rm(e.ticket_price)}</b></p>
        <button class="btn primary block" type="submit">Book now</button>
      </form>`;
  }

  $("#box").innerHTML = `
    <div class="detail">
      <div>
        <span class="badge ${s.cls}">${s.label}</span>
        <h1>${esc(e.title)}</h1>
        <p>${esc(e.description || "No description provided.")}</p>
        <dl class="details">
          <dt>Date</dt><dd>${esc(fmtDate(e.event_date))}</dd>
          <dt>Venue</dt><dd>${esc(e.venue_name || "TBA")}</dd>
          <dt>Location</dt><dd>${esc([e.location, e.city].filter(Boolean).join(", ") || "TBA")}</dd>
          <dt>Organiser</dt><dd>${esc(e.organiser_name || "-")}</dd>
          <dt>Ticket price</dt><dd>${rm(e.ticket_price)}</dd>
          <dt>Availability</dt><dd>${available} of ${e.total_tickets} left ${availBar(available, e.total_tickets)}</dd>
        </dl>
      </div>
      <aside class="panel inner" id="bookPanel"><h3>Book tickets</h3>${bookingPart}</aside>
    </div>`;

  const form = $("#bookForm");
  if (!form) return;

  form.quantity.oninput = () => {
    const q = Number(form.quantity.value);
    $("#total").textContent = rm(q > 0 ? q * e.ticket_price : 0);
  };

  form.onsubmit = async ev => {
    ev.preventDefault();
    const qty = form.quantity.value;
    const errors = {};
    if (!isPosInt(qty)) errors.quantity = "Enter a whole number of 1 or more.";
    else if (Number(qty) > available) errors.quantity = "Only " + available + " tickets are left.";
    if (!showFieldErrors(form, errors)) return;

    await withBusy($("button[type=submit]", form), async () => {
      try {
        const res = await api("POST", "/bookings", { event_id: e.event_id, quantity: Number(qty) });
        const b = res.data;

        $("#bookPanel").innerHTML = `
          <h3>Booking confirmed 🎉</h3>
          <p>Your booking code:</p>
          <p class="code">${esc(b.booking_code)}</p>
          <p>Total paid: <b>${rm(b.total_amount)}</b></p>
          <img class="qr" src="${esc(b.qr_code_url)}" alt="QR code for ${esc(b.booking_code)}">
          <a class="btn primary block" href="#/my-bookings">View my bookings</a>`;

        const fresh = (await api("GET", "/events/" + e.event_id)).data;
        const dl = $(".details dd:last-child");
        if (dl) dl.innerHTML = `${fresh.available_tickets} of ${fresh.total_tickets} left ${availBar(fresh.available_tickets, fresh.total_tickets)}`;
      } catch (err) { showError(err); }
    });
  };
}

async function viewMyBookings() {
  render(`<h1>My bookings</h1><div id="box">Loading…</div>`);
  await loadMyBookings();
}

async function loadMyBookings() {
  try {
    const list = (await api("GET", "/bookings")).data;
    if (!list.length) {
      $("#box").innerHTML = `<div class="empty">You have no bookings yet. <a href="#/events">Browse events</a></div>`;
      return;
    }
    $("#box").innerHTML = `
      <div class="table-wrap"><table>
        <thead><tr><th>Code</th><th>Event</th><th>Date</th><th>Qty</th><th>Total</th><th>Status</th><th></th></tr></thead>
        <tbody>${list.map(b => {
  
          const canCancel = b.status === "confirmed" && !isPast(b.event_date);
          return `<tr>
            <td data-label="Code"><b>${esc(b.booking_code)}</b></td>
            <td data-label="Event">${esc(b.event_title)}</td>
            <td data-label="Date">${esc(fmtDate(b.event_date))}</td>
            <td data-label="Qty">${b.quantity}</td>
            <td data-label="Total">${rm(b.total_amount)}</td>
            <td data-label="Status">${statusBadge(b.status)}</td>
            <td class="row-actions">
              <button class="btn small ghost" data-details="${b.booking_id}">Details</button>
              ${canCancel ? `<button class="btn small danger" data-cancel="${b.booking_id}" data-code="${esc(b.booking_code)}">Cancel</button>` : ""}
            </td></tr>`;
        }).join("")}</tbody></table></div>`;

    $$("[data-details]").forEach(btn => btn.onclick = () => showBookingDetails(btn.dataset.details));
    $$("[data-cancel]").forEach(btn => btn.onclick = () => cancelBooking(btn.dataset.cancel, btn.dataset.code, loadMyBookings));
  } catch (err) { $("#box").innerHTML = errorPanel(err); }
}

async function cancelBooking(id, code, afterDone) {
  const ok = await confirmBox("Cancel booking?", "Booking " + code + " will be cancelled and the tickets returned to the event.", "Yes, cancel it");
  if (!ok) return;
  try {
    const res = await api("PATCH", "/bookings/" + id + "/cancel");
    toast(res.message);
    afterDone();
  } catch (err) { showError(err); }
}

async function showBookingDetails(id) {
  try {
    const b = (await api("GET", "/bookings/" + id)).data;
    const d = openDialog(`
      <h3>Booking ${esc(b.booking_code)}</h3>
      <dl class="details">
        <dt>Event</dt><dd>${esc(b.event_title)}</dd>
        <dt>Date</dt><dd>${esc(fmtDate(b.event_date))}</dd>
        <dt>Venue</dt><dd>${esc(b.venue_name || "-")}${b.location ? " – " + esc(b.location) : ""}</dd>
        <dt>Tickets</dt><dd>${b.quantity}</dd>
        <dt>Total</dt><dd>${rm(b.total_amount)}</dd>
        <dt>Status</dt><dd>${statusBadge(b.status)}</dd>
        <dt>Booked on</dt><dd>${esc(fmtDate(b.created_at))}</dd>
      </dl>
      <img class="qr" src="${esc(b.qr_code_url)}" alt="QR code">
      <div class="actions"><button class="btn primary" id="closeBtn">Close</button></div>`);
    $("#closeBtn", d).onclick = closeDialog;
  } catch (err) { showError(err); }
}
