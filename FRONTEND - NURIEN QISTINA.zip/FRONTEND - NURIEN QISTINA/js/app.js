

const ALL = ["customer", "organiser", "admin"];

const ROUTES = [
  { re: /^\/login$/,                       view: viewLogin,          public: true },
  { re: /^\/register$/,                    view: viewRegister,       public: true },
  { re: /^\/events$/,                      view: viewEvents,         roles: ALL },
  { re: /^\/events\/(\d+)$/,               view: viewEventDetail,    roles: ALL },
  { re: /^\/profile$/,                     view: viewProfile,        roles: ALL },
  { re: /^\/my-bookings$/,                 view: viewMyBookings,     roles: ["customer"] },
  { re: /^\/manage\/events$/,              view: viewManageEvents,   roles: ["organiser", "admin"] },
  { re: /^\/manage\/events\/new$/,         view: () => viewEventForm(null), roles: ["organiser", "admin"] },
  { re: /^\/manage\/events\/(\d+)\/edit$/, view: id => viewEventForm(id),   roles: ["organiser", "admin"] },
  { re: /^\/manage\/venues$/,              view: viewVenues,         roles: ["organiser", "admin"] },
  { re: /^\/admin\/overview$/,             view: viewAdminOverview,  roles: ["admin"] },
  { re: /^\/admin\/users$/,                view: viewAdminUsers,     roles: ["admin"] },
  { re: /^\/admin\/bookings$/,             view: viewAdminBookings,  roles: ["admin"] }
];

const NAV = {
  customer:  [["#/events", "Events"], ["#/my-bookings", "My bookings"], ["#/profile", "Profile"]],
  organiser: [["#/manage/events", "My events"], ["#/manage/venues", "Venues"], ["#/events", "Browse"], ["#/profile", "Profile"]],
  admin:     [["#/admin/overview", "Overview"], ["#/admin/users", "Users"], ["#/manage/venues", "Venues"],
              ["#/manage/events", "Events"], ["#/admin/bookings", "Bookings"], ["#/profile", "Profile"]]
};

const HOME = { customer: "#/events", organiser: "#/manage/events", admin: "#/admin/overview" };

function drawTopbar() {
  const user = Session.user;
  $("#topbar").hidden = !(user && Session.token);
  if ($("#topbar").hidden) return;

  const current = location.hash || "#/";
  $("#nav").innerHTML = NAV[user.role].map(([href, label]) =>
    `<a href="${href}" class="${current.startsWith(href) ? "active" : ""}">${label}</a>`).join("");
  $("#userbox").innerHTML = `
    <span class="who">${esc(user.full_name)} <span class="badge role-${esc(user.role)}">${esc(user.role)}</span></span>
    <button class="btn small ghost" id="logout">Log out</button>`;
  $("#logout").onclick = () => { Session.clear(); toast("You have been logged out."); location.hash = "#/login"; };
  $("#nav").classList.remove("open");
}

function router() {
  const path = (location.hash || "#/").slice(1) || "/";
  const user = Session.user;
  const loggedIn = !!(user && Session.token);

  if (path === "/") { location.hash = loggedIn ? HOME[user.role] : "#/login"; return; }

  const route = ROUTES.map(r => ({ r, m: path.match(r.re) })).find(x => x.m);
  if (!route) {
    drawTopbar();
    render(`<div class="panel error-panel"><strong>Page not found (404)</strong><p>That page does not exist. <a href="#/">Go home</a></p></div>`);
    return;
  }

  if (route.r.public && loggedIn) { location.hash = HOME[user.role]; return; }
  
  if (!route.r.public && !loggedIn) { location.hash = "#/login"; return; }

  drawTopbar();

  if (!route.r.public && !route.r.roles.includes(user.role)) {
    render(`<div class="panel error-panel"><strong>Access denied (403)</strong>
      <p>Your role (<b>${esc(user.role)}</b>) is not allowed to open this page. <a href="#/">Go to my home page</a></p></div>`);
    return;
  }

  route.r.view(route.m[1]);
}

window.addEventListener("hashchange", router);
window.addEventListener("DOMContentLoaded", () => {
  $("#menuBtn").onclick = () => $("#nav").classList.toggle("open");
  router();
});
