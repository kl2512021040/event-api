
async function viewAdminOverview() {
  render(`<h1>System overview</h1><div id="box">Loading…</div>`);
  try {
    const [users, venues, events, bookings] = await Promise.all([
      api("GET", "/users"), api("GET", "/venues"), api("GET", "/events?limit=100"), api("GET", "/bookings")
    ]);
    const u = users.data, b = bookings.data;
    const confirmed = b.filter(x => x.status === "confirmed");
    const revenue = confirmed.reduce((s, x) => s + Number(x.total_amount), 0);
    const count = r => u.filter(x => x.role === r).length;

    $("#box").innerHTML = `
      <div class="stats">
        <div class="stat"><span>Users</span><b>${u.length}</b><small>${count("admin")} admin · ${count("organiser")} organiser · ${count("customer")} customer</small></div>
        <div class="stat"><span>Venues</span><b>${venues.data.length}</b></div>
        <div class="stat"><span>Events</span><b>${events.data.pagination.total_records}</b></div>
        <div class="stat"><span>Confirmed bookings</span><b>${confirmed.length}</b><small>${b.length - confirmed.length} cancelled</small></div>
        <div class="stat"><span>Revenue</span><b>${rm(revenue)}</b></div>
      </div>
      <h2>Latest bookings</h2>
      ${bookingsTable(b.slice(0, 5), false)}
      <p><a href="#/admin/bookings">See all bookings &rarr;</a></p>`;
  } catch (err) { $("#box").innerHTML = errorPanel(err); }
}

async function viewAdminUsers() {
  render(`
    <div class="page-head">
      <h1>Users</h1>
      <button class="btn primary" id="addUser">+ Add user</button>
    </div>
    <div class="toolbar">
      <input id="q" type="search" placeholder="Search name or email…">
      <select id="role">
        <option value="">All roles</option><option>admin</option><option>organiser</option><option>customer</option>
      </select>
    </div>
    <div id="box">Loading…</div>`);

  let users = [];
  const draw = () => {
    const q = $("#q").value.trim().toLowerCase(), role = $("#role").value;
    const rows = users.filter(u => (!role || u.role === role) &&
      (!q || u.full_name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q)));
    $("#box").innerHTML = rows.length ? `
      <div class="table-wrap"><table>
        <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Joined</th></tr></thead>
        <tbody>${rows.map(u => `
          <tr>
            <td data-label="ID">${u.user_id}</td>
            <td data-label="Name"><b>${esc(u.full_name)}</b></td>
            <td data-label="Email">${esc(u.email)}</td>
            <td data-label="Role"><span class="badge role-${esc(u.role)}">${esc(u.role)}</span></td>
            <td data-label="Joined">${esc(fmtDate(u.created_at))}</td>
          </tr>`).join("")}</tbody></table></div>` : `<div class="empty">No users match.</div>`;
  };

  async function load() {
    try { users = (await api("GET", "/users")).data; draw(); }
    catch (err) { $("#box").innerHTML = errorPanel(err); }
  }

  $("#q").oninput = draw;
  $("#role").onchange = draw;
  $("#addUser").onclick = () => addUserDialog(load);
  load();
}

function addUserDialog(done) {
  const d = openDialog(`
    <h3>Add user</h3>
    <form id="userForm" novalidate>
      <label>Full name <input name="full_name"></label>
      <label>Email <input name="email" type="email"></label>
      <label>Password <input name="password" type="password"></label>
      <label>Role
        <select name="role"><option value="customer">customer</option><option value="organiser">organiser</option></select>
      </label>
      <div class="actions">
        <button class="btn ghost" type="button" id="cancelU">Cancel</button>
        <button class="btn primary" type="submit">Add user</button>
      </div>
    </form>`);
  $("#cancelU", d).onclick = closeDialog;

  const form = $("#userForm", d);
  form.onsubmit = async e => {
    e.preventDefault();
    const v = { full_name: form.full_name.value.trim(), email: form.email.value.trim(), password: form.password.value, role: form.role.value };
    const errors = {};
    if (!v.full_name) errors.full_name = "Full name is required.";
    if (!isEmail(v.email)) errors.email = "Enter a valid email address.";
    if (v.password.length < 6) errors.password = "Password must be at least 6 characters.";
    if (!showFieldErrors(form, errors)) return;

    await withBusy($("button[type=submit]", form), async () => {
      try {
        // Admin stays logged in because /auth/register does not return a token
        toast((await api("POST", "/auth/register", v)).message);
        closeDialog();
        done();
      } catch (err) { showError(err); }
    });
  };
}

async function viewAdminBookings() {
  render(`<h1>All bookings</h1><div id="box">Loading…</div>`);
  await loadAdminBookings();
}

async function loadAdminBookings() {
  try {
    const list = (await api("GET", "/bookings")).data;
    $("#box").innerHTML = bookingsTable(list, true);
    $$("[data-cancel]").forEach(btn => btn.onclick = () => cancelBooking(btn.dataset.cancel, btn.dataset.code, loadAdminBookings));
  } catch (err) { $("#box").innerHTML = errorPanel(err); }
}

function bookingsTable(list, withActions) {
  if (!list.length) return `<div class="empty">No bookings yet.</div>`;
  return `
    <div class="table-wrap"><table>
      <thead><tr><th>Code</th><th>Customer</th><th>Event</th><th>Qty</th><th>Total</th><th>Status</th>${withActions ? "<th></th>" : ""}</tr></thead>
      <tbody>${list.map(b => `
        <tr>
          <td data-label="Code"><b>${esc(b.booking_code)}</b></td>
          <td data-label="Customer">${esc(b.customer_name || "-")}</td>
          <td data-label="Event">${esc(b.event_title || "-")}</td>
          <td data-label="Qty">${b.quantity}</td>
          <td data-label="Total">${rm(b.total_amount)}</td>
          <td data-label="Status">${statusBadge(b.status)}</td>
          ${withActions ? `<td class="row-actions">${b.status === "confirmed"
            ? `<button class="btn small danger" data-cancel="${b.booking_id}" data-code="${esc(b.booking_code)}">Cancel</button>` : ""}</td>` : ""}
        </tr>`).join("")}</tbody></table></div>`;
}
