
const Session = {
  get token() { try { return localStorage.getItem("eh_token"); } catch (e) { return null; } },
  get user()  { try { return JSON.parse(localStorage.getItem("eh_user")); } catch (e) { return null; } },
  save(token, user) {
    try { localStorage.setItem("eh_token", token); localStorage.setItem("eh_user", JSON.stringify(user)); } catch (e) {}
  },
  clear() {
    try { localStorage.removeItem("eh_token"); localStorage.removeItem("eh_user"); } catch (e) {}
  }
};

class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}


const STATUS_TITLES = {
  0:   "Network error",
  400: "Invalid input (400)",
  401: "Not logged in / wrong credentials (401)",
  403: "Not allowed for your role (403)",
  404: "Not found (404)",
  405: "Method not allowed (405)",
  500: "Server error (500)"
};


async function api(method, path, body) {
  const headers = { "Accept": "application/json" };
  if (Session.token) headers["Authorization"] = "Bearer " + Session.token;

  const options = { method, headers };
  if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }

  let res;
  try {
    res = await fetch(API_BASE + path, options);
  } catch (e) {
    throw new ApiError(0, "Cannot reach the API. Check that Apache and MySQL are running in XAMPP and that API_BASE in js/config.js is correct.");
  }

  let json = null;
  try { json = await res.json(); } catch (e) { }

  if (!res.ok || (json && json.status === false)) {
    if (res.status === 401 && Session.token && !path.startsWith("/auth/")) {
      Session.clear();
      sessionStorageMessage("Your session expired. Please log in again.");
      location.hash = "#/login";
    }
    const message = (json && json.message) || ("Unexpected response from the server (" + res.status + ").");
    throw new ApiError(res.status, message);
  }
  return json;
}

function sessionStorageMessage(msg) { window.__flash = msg; }
