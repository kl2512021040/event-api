
async function viewManageEvents() {
  const isAdmin = Session.user.role === "admin";
  render(`
    <div class="page-head">
      <h1>${isAdmin ? "All events" : "My events"}</h1>
      <a class="btn primary" href="#/manage/events/new">+ New event</a>
    </div>
    <div id="stats" class="stats"></div>
    <div id="box">Loading…</div>`);
  await loadManageEvents(isAdmin);
}

async function loadManageEvents(isAdmin) {
  try {
    let events = (await api("GET", "/events?limit=100&sort=asc")).data.events;
    if (!isAdmin) events = events.filter(e => Number(e.organiser_id) === Number(Session.user.user_id));

    const sold = e => Number(e.total_tickets) - Number(e.available_tickets);
    const totalSold = events.reduce((s, e) => s + sold(e), 0);
    const revenue = events.reduce((s, e) => s + sold(e) * Number(e.ticket_price), 0);
    $("#stats").innerHTML = `
      <div class="stat"><span>Events</span><b>${events.length}</b></div>
      <div class="stat"><span>Tickets sold</span><b>${totalSold}</b></div>
      <div class="stat"><span>Ticket revenue</span><b>${rm(revenue)}</b></div>`;

    if (!events.length) {
      $("#box").innerHTML = `<div class="empty">No events yet. <a href="#/manage/events/new">Create your first event</a></div>`;
      return;
    }

    $("#box").innerHTML = `
      <div class="table-wrap"><table>
        <thead><tr>
          <th>Event</th><th>Date</th><th>Venue</th>${isAdmin ? "<th>Organiser</th>" : ""}
          <th>Price</th><th>Tickets sold</th><th></th>
        </tr></thead>
        <tbody>${events.map(e => `
          <tr>
            <td data-label="Event"><b>${esc(e.title)}</b></td>
            <td data-label="Date">${esc(fmtDate(e.event_date))}${isPast(e.event_date) ? ' <span class="badge ended">Ended</span>' : ""}</td>
            <td data-label="Venue">${esc(e.venue_name || "-")}</td>
            ${isAdmin ? `<td data-label="Organiser">${esc(e.organiser_name || "-")}</td>` : ""}
            <td data-label="Price">${rm(e.ticket_price)}</td>
            <td data-label="Tickets sold">${sold(e)} / ${e.total_tickets}
              ${soldBar(sold(e), e.total_tickets)}</td>
            <td class="row-actions">
              <a class="btn small ghost" href="#/manage/events/${e.event_id}/edit">Edit</a>
              <button class="btn small danger" data-del="${e.event_id}" data-title="${esc(e.title)}">Delete</button>
            </td>
          </tr>`).join("")}
        </tbody></table></div>`;

    $$("[data-del]").forEach(btn => btn.onclick = async () => {
      const ok = await confirmBox("Delete event?",
        `"${btn.dataset.title}" will be deleted together with all bookings made for it. This cannot be undone.`, "Delete event");
      if (!ok) return;
      try {
        const res = await api("DELETE", "/events/" + btn.dataset.del);
        toast(res.message);
        loadManageEvents(isAdmin);
      } catch (err) { showError(err); }
    });
  } catch (err) { $("#box").innerHTML = errorPanel(err); }
}

async function viewEventForm(id) {
  const editing = !!id;
  render(`
    <p><a href="#/manage/events">&larr; Back to events</a></p>
    <h1>${editing ? "Edit event" : "New event"}</h1>
    <div class="panel" id="box">Loading…</div>`);

  let event = null, venues = [];
  try {
    venues = (await api("GET", "/venues")).data;
    if (editing) event = (await api("GET", "/events/" + id)).data;
  } catch (err) { $("#box").outerHTML = errorPanel(err); return; }

  if (editing && Session.user.role === "organiser" && Number(event.organiser_id) !== Number(Session.user.user_id)) {
    $("#box").outerHTML = `<div class="panel error-panel"><strong>Not allowed</strong><p>You can only edit events that you created.</p></div>`;
    return;
  }

  $("#box").innerHTML = `
    <form id="evForm" novalidate>
      <label>Title <input name="title" maxlength="150" value="${esc(event?.title || "")}"></label>
      <label>Description <textarea name="description" rows="4">${esc(event?.description || "")}</textarea></label>
      <div class="two">
        <label>Date & time <input name="event_date" type="datetime-local" value="${event ? esc(toInputDate(event.event_date)) : ""}"></label>
        <label>Ticket price (RM) <input name="ticket_price" type="number" min="0.01" step="0.01" value="${event ? esc(event.ticket_price) : ""}"></label>
      </div>
      ${editing ? `
        <div class="notice">Venue and ticket numbers cannot be changed after an event is created.
          Venue: <b>${esc(event.venue_name || "-")}</b> · Tickets: <b>${event.available_tickets}</b> of <b>${event.total_tickets}</b> left.</div>`
      : `
        <div class="two">
          <label>Venue
            <select name="venue_id">
              <option value="">Select a venue…</option>
              ${venues.map(v => `<option value="${v.venue_id}" data-cap="${v.capacity}">${esc(v.name)} – ${esc(v.city)} (capacity ${v.capacity})</option>`).join("")}
            </select>
          </label>
          <label>Total tickets <input name="total_tickets" type="number" min="1" step="1"></label>
        </div>`}
      <div class="actions left">
        <button class="btn primary" type="submit">${editing ? "Save changes" : "Create event"}</button>
        <a class="btn ghost" href="#/manage/events">Cancel</a>
      </div>
    </form>`;

  const form = $("#evForm");
  form.onsubmit = async e => {
    e.preventDefault();
    const v = {
      title: form.title.value.trim(),
      description: form.description.value.trim(),
      event_date: form.event_date.value,
      ticket_price: form.ticket_price.value
    };

    const errors = {};
    if (!v.title) errors.title = "Title is required.";
    if (!v.event_date) errors.event_date = "Date and time are required.";
    else if (!editing && new Date(v.event_date) < new Date()) errors.event_date = "Choose a date in the future.";
    if (!(Number(v.ticket_price) > 0)) errors.ticket_price = "Price must be more than 0.";

    if (!editing) {
      v.venue_id = form.venue_id.value;
      v.total_tickets = form.total_tickets.value;
      if (!v.venue_id) errors.venue_id = "Select a venue.";
      if (!isPosInt(v.total_tickets)) errors.total_tickets = "Enter a whole number of 1 or more.";
      else if (v.venue_id) {
        const cap = Number(form.venue_id.selectedOptions[0].dataset.cap);
        if (Number(v.total_tickets) > cap) errors.total_tickets = "More than the venue capacity (" + cap + ").";
      }
    }
    if (!showFieldErrors(form, errors)) return;

    const body = { ...v, event_date: toMysqlDate(v.event_date), ticket_price: Number(v.ticket_price) };
    if (!editing) { body.venue_id = Number(v.venue_id); body.total_tickets = Number(v.total_tickets); }

    await withBusy($("button[type=submit]", form), async () => {
      try {
        const res = editing ? await api("PUT", "/events/" + id, body) : await api("POST", "/events", body);
        toast(res.message);
        location.hash = "#/manage/events";
      } catch (err) { showError(err); }
    });
  };
}

async function viewVenues() {
  render(`
    <div class="page-head">
      <h1>Venues</h1>
      <button class="btn primary" id="addVenue">+ New venue</button>
    </div>
    <div id="box">Loading…</div>`);
  $("#addVenue").onclick = () => venueDialog(null);
  await loadVenues();
}

async function loadVenues() {
  try {
    const venues = (await api("GET", "/venues")).data;
    if (!venues.length) { $("#box").innerHTML = `<div class="empty">No venues yet.</div>`; return; }
    $("#box").innerHTML = `
      <div class="table-wrap"><table>
        <thead><tr><th>Name</th><th>Location</th><th>City</th><th>Capacity</th><th>Added by</th><th></th></tr></thead>
        <tbody>${venues.map(v => `
          <tr>
            <td data-label="Name"><b>${esc(v.name)}</b></td>
            <td data-label="Location">${esc(v.location)}</td>
            <td data-label="City">${esc(v.city)}</td>
            <td data-label="Capacity">${Number(v.capacity).toLocaleString()}</td>
            <td data-label="Added by">${esc(v.created_by_name || "-")}</td>
            <td class="row-actions">
              <button class="btn small ghost" data-edit="${v.venue_id}">Edit</button>
              <button class="btn small danger" data-del="${v.venue_id}" data-name="${esc(v.name)}">Delete</button>
            </td>
          </tr>`).join("")}</tbody></table></div>`;

    $$("[data-edit]").forEach(b => b.onclick = () => venueDialog(venues.find(v => v.venue_id == b.dataset.edit)));
    $$("[data-del]").forEach(b => b.onclick = async () => {
      const ok = await confirmBox("Delete venue?",
        `"${b.dataset.name}" will be deleted together with every event held there and their bookings.`, "Delete venue");
      if (!ok) return;
      try { toast((await api("DELETE", "/venues/" + b.dataset.del)).message); loadVenues(); }
      catch (err) { showError(err); }
    });
  } catch (err) { $("#box").innerHTML = errorPanel(err); }
}

function venueDialog(venue) {
  const d = openDialog(`
    <h3>${venue ? "Edit venue" : "New venue"}</h3>
    <form id="venueForm" novalidate>
      <label>Name <input name="name" value="${esc(venue?.name || "")}"></label>
      <label>Location / address <input name="location" value="${esc(venue?.location || "")}"></label>
      <div class="two">
        <label>City <input name="city" value="${esc(venue?.city || "")}"></label>
        <label>Capacity <input name="capacity" type="number" min="1" step="1" value="${esc(venue?.capacity || "")}"></label>
      </div>
      <div class="actions">
        <button class="btn ghost" type="button" id="cancelV">Cancel</button>
        <button class="btn primary" type="submit">${venue ? "Save" : "Add venue"}</button>
      </div>
    </form>`);
  $("#cancelV", d).onclick = closeDialog;

  const form = $("#venueForm", d);
  form.onsubmit = async e => {
    e.preventDefault();
    const v = { name: form.name.value.trim(), location: form.location.value.trim(), city: form.city.value.trim(), capacity: form.capacity.value };
    const errors = {};
    if (!v.name) errors.name = "Name is required.";
    if (!v.location) errors.location = "Location is required.";
    if (!v.city) errors.city = "City is required.";
    if (!isPosInt(v.capacity)) errors.capacity = "Enter a whole number of 1 or more.";
    if (!showFieldErrors(form, errors)) return;
    v.capacity = Number(v.capacity);

    await withBusy($("button[type=submit]", form), async () => {
      try {
        const res = venue ? await api("PUT", "/venues/" + venue.venue_id, v) : await api("POST", "/venues", v);
        toast(res.message);
        closeDialog();
        loadVenues();
      } catch (err) { showError(err); }
    });
  };
}
