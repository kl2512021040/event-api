

function viewLogin() {
  const flash = window.__flash; window.__flash = null;
  render(`
    <div class="auth-card panel">
      <h1>Welcome back</h1>
      <p class="muted">Log in to browse events, book tickets or manage the system.</p>
      ${flash ? `<div class="notice">${esc(flash)}</div>` : ""}
      <form id="loginForm" novalidate>
        <label>Email <input name="email" type="email" autocomplete="username"></label>
        <label>Password <input name="password" type="password" autocomplete="current-password"></label>
        <button class="btn primary block" type="submit">Log in</button>
      </form>
      <p class="muted center">No account? <a href="#/register">Register</a></p>
    </div>`);

  const form = $("#loginForm");
  form.onsubmit = async e => {
    e.preventDefault();
    const email = form.email.value.trim(), password = form.password.value;

  
    const errors = {};
    if (!email) errors.email = "Email is required.";
    else if (!isEmail(email)) errors.email = "Enter a valid email address.";
    if (!password) errors.password = "Password is required.";
    if (!showFieldErrors(form, errors)) return;

 
    await withBusy($("button[type=submit]", form), async () => {
      try {
        const res = await api("POST", "/auth/login", { email, password });
        Session.save(res.data.token, res.data.user);
        toast("Welcome, " + res.data.user.full_name + "!");
        location.hash = "#/";         
      } catch (err) { showError(err); }
    });
  };
}

function viewRegister() {
  render(`
    <div class="auth-card panel">
      <h1>Create an account</h1>
      <form id="regForm" novalidate>
        <label>Full name <input name="full_name" autocomplete="name"></label>
        <label>Email <input name="email" type="email" autocomplete="username"></label>
        <label>Password <input name="password" type="password" autocomplete="new-password"></label>
        <label>Confirm password <input name="confirm" type="password" autocomplete="new-password"></label>
        <label>I am a
          <select name="role">
            <option value="customer">Customer (buy tickets)</option>
            <option value="organiser">Organiser (run events)</option>
          </select>
        </label>
        <button class="btn primary block" type="submit">Register</button>
      </form>
      <p class="muted center">Already registered? <a href="#/login">Log in</a></p>
    </div>`);

  const form = $("#regForm");
  form.onsubmit = async e => {
    e.preventDefault();
    const v = {
      full_name: form.full_name.value.trim(),
      email: form.email.value.trim(),
      password: form.password.value,
      role: form.role.value
    };
    const errors = {};
    if (!v.full_name) errors.full_name = "Full name is required.";
    if (!v.email) errors.email = "Email is required.";
    else if (!isEmail(v.email)) errors.email = "Enter a valid email address.";
    if (v.password.length < 6) errors.password = "Password must be at least 6 characters.";
    if (form.confirm.value !== v.password) errors.confirm = "Passwords do not match.";
    if (!showFieldErrors(form, errors)) return;

    await withBusy($("button[type=submit]", form), async () => {
      try {
        await api("POST", "/auth/register", v);
        window.__flash = "Account created. You can log in now.";
        location.hash = "#/login";
      } catch (err) { showError(err); }
    });
  };
}

async function viewProfile() {
  render(`<h1>My profile</h1><div id="box" class="panel">Loading…</div>`);
  try {
    const u = (await api("GET", "/users/profile")).data;
    $("#box").innerHTML = `
      <dl class="details">
        <dt>Name</dt><dd>${esc(u.full_name)}</dd>
        <dt>Email</dt><dd>${esc(u.email)}</dd>
        <dt>Role</dt><dd><span class="badge role-${esc(u.role)}">${esc(u.role)}</span></dd>
        <dt>Member since</dt><dd>${esc(fmtDate(u.created_at))}</dd>
      </dl>`;
  } catch (err) { $("#box").outerHTML = errorPanel(err); }
}
