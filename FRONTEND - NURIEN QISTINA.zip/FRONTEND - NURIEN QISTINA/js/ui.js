

const $  = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];

const esc = s => String(s ?? "").replace(/[&<>"']/g, c =>
  ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const rm = n => "RM " + Number(n || 0).toLocaleString("en-MY", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const parseDate = s => new Date(String(s).replace(" ", "T"));
const fmtDate = s => parseDate(s).toLocaleString("en-MY", { day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" });
const isPast = s => parseDate(s) < new Date();

const toInputDate = s => String(s).replace(" ", "T").slice(0, 16);
const toMysqlDate = v => v.replace("T", " ") + (v.length === 16 ? ":00" : "");

function render(html) { $("#view").innerHTML = html; window.scrollTo(0, 0); }

function toast(message, type = "ok") {
  const el = document.createElement("div");
  el.className = "toast " + type;
  el.textContent = message;
  $("#toasts").appendChild(el);
  setTimeout(() => el.remove(), type === "error" ? 7000 : 3500);
}

function showError(err) {
  if (err instanceof ApiError) {
    const title = STATUS_TITLES[err.status] || ("Error (" + err.status + ")");
    toast(title + " — " + err.message, "error");
  } else {
    console.error(err);
    toast("Something went wrong: " + err.message, "error");
  }
}

function errorPanel(err) {
  const title = err instanceof ApiError ? (STATUS_TITLES[err.status] || "Error") : "Error";
  return `<div class="panel error-panel"><strong>${esc(title)}</strong><p>${esc(err.message)}</p></div>`;
}

function openDialog(html) {
  const d = $("#dialog");
  d.innerHTML = html;
  d.returnValue = "";          
  if (!d.open) d.showModal();
  return d;
}
function closeDialog() { const d = $("#dialog"); if (d.open) d.close(); }

function confirmBox(title, text, okLabel = "Confirm") {
  return new Promise(resolve => {
    const d = openDialog(`
      <h3>${esc(title)}</h3>
      <p>${esc(text)}</p>
      <div class="actions">
        <button class="btn ghost" data-v="0">Cancel</button>
        <button class="btn danger" data-v="1">${esc(okLabel)}</button>
      </div>`);
    d.onclose = () => resolve(d.returnValue === "1");
    $$("button", d).forEach(b => b.onclick = () => d.close(b.dataset.v));
  });
}

function clearFieldErrors(form) {
  $$(".field-error", form).forEach(e => e.remove());
  $$(".invalid", form).forEach(e => e.classList.remove("invalid"));
}
function showFieldErrors(form, errors) {
  clearFieldErrors(form);
  let first = null;
  for (const name in errors) {
    const input = form.elements[name];
    if (!input) continue;
    input.classList.add("invalid");
    const msg = document.createElement("div");
    msg.className = "field-error";
    msg.textContent = errors[name];
    input.insertAdjacentElement("afterend", msg);
    if (!first) first = input;
  }
  if (first) first.focus();
  return Object.keys(errors).length === 0;
}
const isEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const isPosInt = v => /^\d+$/.test(String(v)) && Number(v) > 0;

async function withBusy(btn, fn) {
  btn.disabled = true;
  const old = btn.textContent;
  btn.textContent = "Please wait…";
  try { return await fn(); }
  finally { btn.disabled = false; btn.textContent = old; }
}

function availBar(available, total) {
  const pct = total > 0 ? Math.round((available / total) * 100) : 0;
  return `<div class="bar" title="${available} of ${total} left"><span style="width:${pct}%"></span></div>`;
}

function soldBar(sold, total) {
  const pct = total > 0 ? Math.round((sold / total) * 100) : 0;
  return `<div class="bar sold" title="${pct}% sold"><span style="width:${pct}%"></span></div>`;
}

function statusBadge(status) {
  return `<span class="badge ${esc(status)}">${esc(status)}</span>`;
}
